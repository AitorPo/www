<!-- DOCTYPE + HEADER -->
<?php include_once 'includes/header.php'?>
<!-- SIDEBAR -->
<?php include_once 'includes/sidebar.php'?>
<!-- BODY -->
<?php include_once 'includes/body.php'?>
<!-- FOOTER -->
<?php include_once 'includes/footer.php'?>
</body>
</html>